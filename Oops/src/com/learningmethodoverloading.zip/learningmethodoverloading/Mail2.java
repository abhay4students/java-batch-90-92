package com.learningmethodoverloading;

public class Mail2 extends Mail{
	void compose(String to,String sub,String body,String cc)
	{
		
	}
}
