package com.isarelationship;

public class Dog extends Animal {
	
	Dog() 
	{
		eyes=3;
	}
}
