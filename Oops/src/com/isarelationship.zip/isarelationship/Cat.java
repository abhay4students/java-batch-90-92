package com.isarelationship;

public class Cat extends Animal{

}
