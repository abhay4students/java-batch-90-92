package com.isarelationship;

import com.learnnghasarelationship.Mobile;

public class Demo1 extends Mobile{
	int a=30;
	int b=100;
	void test()
	{
		System.out.println("Inside test()");
	}
	
	void disp()
	{
		System.out.println("Inside disp()");
	}
			

}
