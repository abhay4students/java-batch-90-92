package com.isarelationship;

public class Animal {
	int eyes=2;
	int ears=2;
	void run()
	{
		System.out.println("Running using 4 legs");
	}
}
