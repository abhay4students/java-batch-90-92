package com.isarelationship;

public class MainClass {
	public static void main(String[] args) {
		 Demo2 d2=new Demo2();
		 d2.disp();
		 System.out.println("a value is :"+d2.a);
		 d2.m();
		 d2.test();
		 d2.charging();
		 d2.music("Abc");
		 
		 Demo1 d1=new Demo1();
		 d1.disp();
		 d1.charging();
		 
		 
		 Animal a1=new Animal();
		 
		 
	}

}
