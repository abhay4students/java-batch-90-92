package com.isarelationship;

public class Human extends Animal{
	void run()
	{
		System.out.println("Running using 2 legs");
	}
}
