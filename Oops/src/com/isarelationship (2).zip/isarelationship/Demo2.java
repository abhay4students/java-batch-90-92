package com.isarelationship;

public class Demo2 extends Demo1{
	double x=90.9;
	void m()
	{
		System.out.println("Inside m()");
	}

}
