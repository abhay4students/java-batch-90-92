package com.isarelationship;

public class MainClass2 {
	public static void main(String[] args) {
		
		Dog d1=new Dog();
		d1.run();
		
		
		System.out.println(d1.eyes);
		Human h1=new Human();
		h1.run();
	}

}
