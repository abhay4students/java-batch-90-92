package com.isarelationship;

public class Tiger extends Animal{

}
