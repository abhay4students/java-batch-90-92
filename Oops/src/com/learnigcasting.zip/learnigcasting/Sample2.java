package com.learnigcasting;

public class Sample2 extends Sample1{
	double d=23.5;
	void disp()
	{
		System.out.println("Displaying......");
	}

}
