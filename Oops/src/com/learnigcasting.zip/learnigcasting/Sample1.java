package com.learnigcasting;

public class Sample1 {
	int a=100;
	int b=300;
	void test()
	{
		System.out.println("Testing....");
	}

}
