package com.learnigcasting;

public class Demo1 {
	public static void main(String[] args) {
		
		int a=(int)2.5;
		System.out.println(a);
		
		double d=4;
		
		int x='A';
		
		short s1='b';
		
		byte b1='C';
		
		System.out.println(b1);
		
		System.out.println(d);
	}
}
