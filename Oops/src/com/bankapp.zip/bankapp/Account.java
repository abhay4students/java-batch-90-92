package com.bankapp;

public class Account {
	int accNum;
	String custName;
	double accBal;
	
	void deposit(double amt)
	{
		System.out.println("depositing "+amt);
		accBal=accBal+amt;
	}
	void withdrawal(double amt)
	{
		System.out.println("Withdrawing "+amt);
		accBal=accBal-amt;
	}
	void checkBalance()
	{
		System.out.println("Account Ablance :"+accBal);
	}

}
