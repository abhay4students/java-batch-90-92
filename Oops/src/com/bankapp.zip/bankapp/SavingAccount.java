package com.bankapp;

public class SavingAccount extends Account{
	SavingAccount(int accNum,String custName,double accBal)
	{
		this.accNum=accNum;
		this.custName=custName;
		this.accBal=accBal;
	}

}
