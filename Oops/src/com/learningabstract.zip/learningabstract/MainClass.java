package com.learningabstract;

public class MainClass {
	public static void main(String[] args) {
		Demo2 d2=new Demo2();
		d2.test();
	}

}
