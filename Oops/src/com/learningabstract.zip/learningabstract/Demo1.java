package com.learningabstract;

public abstract class Demo1 {
	abstract void test();
	void disp()
	{
		System.out.println("Inside disp()");
	}
	abstract int m(int a);
}
