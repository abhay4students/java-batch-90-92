package com.learningabstract;

public  class Demo2 extends Demo1{
	void test()
	{
		System.out.println("Indise Demo2");
	}
	int m(int a)
	{
		System.out.println("Inside Demo2 m()");
		return 20;
	}
}
