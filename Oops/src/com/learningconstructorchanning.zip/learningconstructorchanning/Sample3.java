package com.learningconstructorchanning;

public class Sample3 extends Sample2{
	Sample3()
	{
		super(40,20);
	}
}
