package com.learningconstructorchanning;

public class MainClass {
	public static void main(String[] args) {
		//Sample2 s2=new Sample2(30,60);
		Sample3 s2=new Sample3();
	}

}
