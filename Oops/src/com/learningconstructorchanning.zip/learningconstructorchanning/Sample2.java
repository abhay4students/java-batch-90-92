package com.learningconstructorchanning;

public class Sample2 extends Sample1{
	int x;
	int y;

	Sample2(int x,int y) {
		super(10,60);
		this.x=x;
		this.y=y;

	}
	Sample2()
	{
		super(40,40);
	}
}
