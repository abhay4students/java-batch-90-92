package com.learningconstructorchanning;

public class Sample1 {
	int i=90;
	int j;
	
	Sample1(int i,int j)
	{
		this.i=i;
		this.j=j;
	}

}
